static partial class GameEngine
{
    public const int Floor = 0, Wall = 1, Diamond = 2, Exit = 3;
    public const int Player = 4, Creeper = 5, Pickaxe = 6;
    public const int Spark = 7, Burst = 8;
    public const int FinalLevel = 3;
    private static readonly (int Row, int Col)[] Directions =
        { (-1, 0), (0, -1), (1, 0), (0, 1) };

    // This is the single place to change how a move crosses the board edges.
    public static (int Row, int Col) GetNeighbor(int[,] board, int row, int col,
        int deltaRow, int deltaCol) => (row + deltaRow, col + deltaCol);

    private static bool IsNeighbor(int[,] board, int fromRow, int fromCol, int row, int col)
    {
        foreach (var (deltaRow, deltaCol) in Directions)
        {
            if (GetNeighbor(board, fromRow, fromCol, deltaRow, deltaCol) == (row, col))
                return true;
        }
        return false;
    }

    public static bool InBounds(int[,] board, int row, int col) =>
        row >= 0 && row < board.GetLength(0) && col >= 0 && col < board.GetLength(1);

    // Starter behaviour for the challenge task. The creeper moves directly
    // towards the player and can get stuck behind walls.
    public static bool TryGetDirectStep(int[,] board, int fromRow, int fromCol,
        int playerRow, int playerCol, out int nextRow, out int nextCol)
    {
        int distance = Math.Abs(fromRow - playerRow) + Math.Abs(fromCol - playerCol);
        foreach (var (dr, dc) in Directions)
        {
            var (row, col) = GetNeighbor(board, fromRow, fromCol, dr, dc);
            if (InBounds(board, row, col) && board[row, col] != Wall &&
                Math.Abs(row - playerRow) + Math.Abs(col - playerCol) < distance)
            {
                nextRow = row;
                nextCol = col;
                return true;
            }
        }
        nextRow = fromRow;
        nextCol = fromCol;
        return false;
    }

    public sealed class Round
    {
        private readonly int[,] map;
        private readonly int level;
        private int patrolDirection;
        private int playerMoves;

        public int[,] Board { get; private set; } = null!;
        public int PlayerRow { get; private set; }
        public int PlayerCol { get; private set; }
        public int CreeperRow { get; private set; }
        public int CreeperCol { get; private set; }
        public int Diamonds { get; private set; }
        public int PickaxeUses { get; private set; }
        public bool Finished { get; private set; }
        public bool Won { get; private set; }
        public string Message { get; set; } = "";

        public Round(int[,] map, int level)
        {
            this.map = map;
            this.level = level;
            Reset();
        }

        public void Reset()
        {
            Board = (int[,])map.Clone();
            Diamonds = 0;
            PickaxeUses = 0;
            playerMoves = 0;
            Finished = false;
            Won = false;
            Message = "Collect all diamonds, then reach the exit.";

            for (int row = 0; row < Board.GetLength(0); row++)
            {
                for (int col = 0; col < Board.GetLength(1); col++)
                {
                    switch (Board[row, col])
                    {
                        case Player:
                            (PlayerRow, PlayerCol) = (row, col);
                            Board[row, col] = Floor;
                            break;
                        case Creeper:
                            (CreeperRow, CreeperCol) = (row, col);
                            Board[row, col] = Floor;
                            break;
                        case Diamond:
                            Diamonds++;
                            break;
                    }
                }
            }
            patrolDirection = level == 1 ? ChoosePatrolDirection() : -1;
        }

        public int Move(int deltaRow, int deltaCol)
        {
            var (row, col) = GetNeighbor(Board, PlayerRow, PlayerCol, deltaRow, deltaCol);

            if (!GameTasks.CanMoveTo(Board, row, col))
            {
                // A failed action never advances the creeper.
                if (!InBounds(Board, row, col) || Board[row, col] != Wall ||
                    !GameTasks.TryBreakWall(Board, row, col, PickaxeUses))
                {
                    Message = "That move is blocked.";
                    return 0;
                }

                PickaxeUses--;
            }

            playerMoves++;
            (PlayerRow, PlayerCol) = (row, col);
            if (Caught())
                return Lose();

            int effect = 0;
            Message = "Keep going.";
            switch (Board[row, col])
            {
                case Diamond:
                    Board[row, col] = Floor;
                    Diamonds--;
                    effect = Spark;
                    Message = Diamonds == 0 ? "Exit unlocked!" : "Diamond collected.";
                    break;
                case Pickaxe:
                    Board[row, col] = Floor;
                    PickaxeUses++;
                    effect = Spark;
                    Message = "Pickaxe collected. Walk into a wall to use it.";
                    break;
                case Exit when Diamonds == 0:
                    Finished = true;
                    Won = true;
                    Message = "Exit reached!";
                    return Spark;
                case Exit:
                    Message = "Collect all diamonds to unlock the exit.";
                    break;
            }

            int burstEvery = level == FinalLevel ? 2 : 4;
            int creeperSteps = level > 1 && playerMoves % burstEvery == 0 ? 2 : 1;
            if (level > 1 && Message == "Keep going." && (playerMoves + 1) % burstEvery == 0)
                Message = "Heads up! Creeper lunges next turn.";
            for (int step = 0; step < creeperSteps; step++)
            {
                MoveCreeper();
                if (Caught())
                    return Lose();
            }
            return effect;
        }

        private bool Caught() => PlayerRow == CreeperRow && PlayerCol == CreeperCol;

        private int Lose()
        {
            Finished = true;
            Message = "The creeper caught you!";
            return Burst;
        }

        private void MoveCreeper()
        {
            if (level > 1)
            {
                if (GameTasks.TryGetCreeperStep(Board, CreeperRow, CreeperCol,
                    PlayerRow, PlayerCol, out int row, out int col) &&
                    IsNeighbor(Board, CreeperRow, CreeperCol, row, col) &&
                    InBounds(Board, row, col) && Board[row, col] != Wall)
                    (CreeperRow, CreeperCol) = (row, col);

                return;
            }

            if (patrolDirection < 0 || !CanPatrol(patrolDirection))
                patrolDirection = ChoosePatrolDirection();
            if (patrolDirection < 0)
                return;

            var (dr, dc) = Directions[patrolDirection];
            (CreeperRow, CreeperCol) = GetNeighbor(Board, CreeperRow, CreeperCol, dr, dc);
        }

        private int ChoosePatrolDirection()
        {
            Span<int> available = stackalloc int[Directions.Length];
            int count = 0;
            for (int direction = 0; direction < Directions.Length; direction++)
            {
                if (CanPatrol(direction))
                    available[count++] = direction;
            }
            return count == 0 ? -1 : available[Random.Shared.Next(count)];
        }

        private bool CanPatrol(int direction)
        {
            var (dr, dc) = Directions[direction];
            var (row, col) = GetNeighbor(Board, CreeperRow, CreeperCol, dr, dc);
            return InBounds(Board, row, col) && Board[row, col] != Wall;
        }
    }
}
