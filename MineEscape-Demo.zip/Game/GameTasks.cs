// כתבו כאן את שמכם המלא
static class GameTasks
{
    private const int Floor = GameEngine.Floor;
    private const int Wall = GameEngine.Wall;

    // TODO 1
    // בדקו שהשורה והעמודה בתוך הלוח. רק אחר כך בדקו שהיעד אינו קיר
    public static bool CanMoveTo(int[,] board, int row, int col)
    {
        return row >= 0 && row < board.GetLength(0)
            && col >= 0 && col < board.GetLength(1)
            && board[row, col] != Wall;
    }

    // TODO 2
    // אם נותר שימוש במכוש והיעד הוא קיר בתוך הלוח, החליפו אותו ברצפה
    // המשחק מפחית שימוש אחד לאחר שבירה מוצלחת
    public static bool TryBreakWall(int[,] board, int row, int col, int uses)
    {
        if (uses <= 0 || !GameEngine.InBounds(board, row, col) || board[row, col] != Wall)
            return false;

        board[row, col] = Floor;
        return true;
    }

    // משימת אתגר – מצאו צעד אחד במסלול הקצר ביותר מהקריפר אל השחקן
    public static bool TryGetCreeperStep(int[,] board, int fromRow, int fromCol,
        int playerRow, int playerCol, out int nextRow, out int nextCol)
    {
        nextRow = fromRow;
        nextCol = fromCol;
        int rows = board.GetLength(0);
        int cols = board.GetLength(1);
        int[,] distances = new int[rows, cols];
        // כל שורה מתארת צעד אחד לפי הסדר למעלה, שמאלה, למטה וימינה
        // העמודה הראשונה שומרת שינוי בשורה והשנייה שינוי בעמודה
        int[,] directions =
        {
            { -1,  0 },
            {  0, -1 },
            {  1,  0 },
            {  0,  1 }
        };

        // מחפשים מהשחקן החוצה, שכבה אחר שכבה
        // אפס מסמן תא שטרם נמצא. הערך בתא שנמצא גדול באחד מהמרחק האמיתי
        // התור הוא טבלה שבה כל שורה שומרת את הקואורדינטות של תא אחד במפה
        // העמודה הראשונה שומרת מספר שורה במפה והשנייה מספר עמודה במפה
        // קוראים מראש התור ומוסיפים לסופו. תחילה התור מכיל רק את תא השחקן
        int[,] queue = new int[rows * cols, 2];
        // המקום של התא הבא שמחכה לבדיקה
        int head = 0;
        // המקום הפנוי הבא להוספה לתור
        int tail = 1;
        queue[0, 0] = playerRow;
        queue[0, 1] = playerCol;
        // המרחק של השחקן מעצמו הוא אפס, ולכן בתא שלו כותבים אחת
        distances[playerRow, playerCol] = 1;

        while (head < tail && distances[fromRow, fromCol] == 0)
        {
            int row = queue[head, 0];
            int col = queue[head, 1];
            head++;

            for (int direction = 0; direction < directions.GetLength(0); direction++)
            {
                var (neighborRow, neighborCol) = GameEngine.GetNeighbor(board, row, col,
                    directions[direction, 0], directions[direction, 1]);
                if (!CanMoveTo(board, neighborRow, neighborCol) ||
                    distances[neighborRow, neighborCol] != 0)
                    continue;

                // TODO 3.1
                // שמרו בתא של השכן את הערך שבתא הנוכחי ועוד צעד אחד
                // הסימון לפני ההוספה לתור מבטיח שכל תא ייכנס לתור פעם אחת
                distances[neighborRow, neighborCol] = distances[row, col] + 1;
                queue[tail, 0] = neighborRow;
                queue[tail, 1] = neighborCol;
                tail++;
            }
        }

        int distance = distances[fromRow, fromCol];
        if (distance <= 1)
            return false;

        for (int direction = 0; direction < directions.GetLength(0); direction++)
        {
            var (row, col) = GameEngine.GetNeighbor(board, fromRow, fromCol,
                directions[direction, 0], directions[direction, 1]);
            // TODO 3.2
            // בדקו קודם שאפשר לעבור לשכן. רק אז קראו את הערך שלו
            // לשכן הנבחר צריך להיות ערך קטן באחד מהערך בתא הקריפר
            bool isCloser = CanMoveTo(board, row, col) && distances[row, col] == distance - 1;
            if (isCloser)
            {
                nextRow = row;
                nextCol = col;
                return true;
            }
        }

        return false;
    }
}
