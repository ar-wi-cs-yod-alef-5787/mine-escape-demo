# Mine Escape demo

Complete reference solution for the classroom game. Collect all diamonds, then reach the exit. Use the on-screen arrows on your phone. Walk into a wall after collecting a pickaxe to break it.

Three levels: Patrol, Pursuit, Frenzy. The console and website share the C# game logic and map.

The private student template is maintained separately.

Published through GitHub Actions and GitHub Pages. In repository Settings → Pages, select GitHub Actions as the source.
