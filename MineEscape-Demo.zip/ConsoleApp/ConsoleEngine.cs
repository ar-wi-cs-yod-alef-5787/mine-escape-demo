using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Text;

static partial class GameEngine
{
    private const int StatusWidth = 61;
    private const int InterfaceRows = 5;

    // Use symbols that typically occupy two terminal columns in emoji mode.
    private static readonly string[] Emoji = { "⬛", "🧱", "💎", "🚪", "🧑", "😈", "⛏️", "✨", "💥" };
    private static readonly string[] Ascii = { " .", "##", " *", " E", " @", " C", " P", " +", " !" };

    public static void Run(bool ascii, string[] args)
    {
        int level = 1;
        int unlocked = 1;
        var round = new Round(LevelMap(level), level);
        if (OperatingSystem.IsWindows() &&
            !WindowsConsole.ContinueInThisWindow(args, ascii, RequiredWidth(round),
                round.Board.GetLength(0) + InterfaceRows))
            return;
        Console.Clear();

        try
        {
            Draw(round, ascii, level, unlocked, Spark);
            Thread.Sleep(180);
            while (true)
            {
                bool frameFits = Draw(round, ascii, level, unlocked);
                var key = Console.ReadKey(intercept: true).Key;
                if (key == ConsoleKey.Escape)
                    break;

                if (key == ConsoleKey.F2)
                {
                    ascii = !ascii;
                    Console.Clear();
                    continue;
                }

                int requestedLevel = key switch
                {
                    ConsoleKey.D1 or ConsoleKey.NumPad1 => 1,
                    ConsoleKey.D2 or ConsoleKey.NumPad2 => 2,
                    ConsoleKey.D3 or ConsoleKey.NumPad3 => 3,
                    _ => 0
                };
                if (requestedLevel > 0)
                {
                    if (requestedLevel > unlocked)
                        round.Message = $"Finish level {requestedLevel - 1} to unlock level {requestedLevel}.";
                    else
                    {
                        level = requestedLevel;
                        round = new Round(LevelMap(level), level);
                        Console.Clear();
                    }
                    continue;
                }

                if (key == ConsoleKey.R)
                {
                    if (round.Finished)
                        Console.Clear();
                    round.Reset();
                    continue;
                }

                if (!frameFits || round.Finished)
                    continue;

                var (deltaRow, deltaCol) = key switch
                {
                    ConsoleKey.W or ConsoleKey.UpArrow => (-1, 0),
                    ConsoleKey.A or ConsoleKey.LeftArrow => (0, -1),
                    ConsoleKey.S or ConsoleKey.DownArrow => (1, 0),
                    ConsoleKey.D or ConsoleKey.RightArrow => (0, 1),
                    _ => (0, 0)
                };
                if (deltaRow == 0 && deltaCol == 0)
                    continue;

                int effect = round.Move(deltaRow, deltaCol);
                if (effect != 0)
                {
                    Draw(round, ascii, level, unlocked, effect);
                    Thread.Sleep(effect == Burst ? 220 : 130);
                }
                if (round.Won && level < FinalLevel)
                {
                    Draw(round, ascii, level, unlocked);
                    Thread.Sleep(1800);
                    level++;
                    unlocked = Math.Max(level, unlocked);
                    round = new Round(LevelMap(level), level);
                    Console.Clear();
                }
            }
        }
        finally
        {
            Console.Clear();
        }
    }

    private static int RequiredWidth(Round round) =>
        Math.Max(StatusWidth, 2 * round.Board.GetLength(1)) + 1;

    private static bool Draw(Round round, bool ascii, int level, int unlocked, int effect = 0)
    {
        int width = Console.WindowWidth;
        int height = Console.WindowHeight;
        int rows = round.Board.GetLength(0) + InterfaceRows;
        int columns = RequiredWidth(round);
        if (width > 0 && height > 0 && (width < columns || height < rows))
        {
            Console.Clear();
            string hint = $"Resize or zoom out: {columns} columns x {rows} rows. Esc quits.";
            Console.Write(hint[..Math.Min(hint.Length, width - 1)]);
            return false;
        }
        if (round.Finished && effect == 0)
        {
            DrawResult(round.Won, ascii, level, rows, width > 0 ? width : columns);
            return true;
        }

        var symbols = ascii ? Ascii : Emoji;
        string creeper = ascii ? Ascii[Creeper] : level switch
        {
            1 => Emoji[Creeper],
            2 => "👺",
            _ => "👹"
        };
        var frame = new StringBuilder();
        string mode = level switch { 1 => "patrol", 2 => "chase", _ => "chase x1.5" };
        frame.AppendLine(($"MINE ESCAPE | Level {level} | Creeper: {mode}").PadRight(StatusWidth));
        string inventory = level == 1
            ? $"Diamonds left: {round.Diamonds}"
            : $"Diamonds left: {round.Diamonds} | Pickaxe uses: {round.PickaxeUses}";
        frame.AppendLine(inventory);

        for (int row = 0; row < round.Board.GetLength(0); row++)
        {
            for (int col = 0; col < round.Board.GetLength(1); col++)
            {
                int tile = round.Board[row, col];
                if (row == round.CreeperRow && col == round.CreeperCol)
                    tile = Creeper;
                if (row == round.PlayerRow && col == round.PlayerCol)
                    tile = effect == 0 ? Player : effect;

                frame.Append(tile == Creeper ? creeper : symbols[tile]);
            }
            frame.AppendLine();
        }

        frame.AppendLine(round.Message.PadRight(StatusWidth));
        frame.AppendLine("WASD/arrows Move | R Retry | F2 Symbols | Esc Quit");
        frame.Append($"Replay unlocked levels: {(unlocked == 1 ? "1" : $"1-{unlocked}")}");
        Console.SetCursorPosition(0, 0);
        Console.Write(frame.ToString());
        return true;
    }

    private static void DrawResult(bool won, bool ascii, int level, int rows, int width)
    {
        const int innerWidth = 46;
        int left = (width - innerWidth - 2) / 2;
        int top = (rows - 7) / 2;
        string margin = new(' ', left);
        char[] border = ascii ? "+-+|++".ToCharArray() : "╔═╗║╚╝".ToCharArray();

        ConsoleColor accent;
        string title;
        string subtitle;
        string footer;
        int titleWidth;
        if (!won)
        {
            accent = ConsoleColor.Red;
            title = "GAME OVER";
            titleWidth = title.Length + (ascii ? 0 : 4);
            if (!ascii)
                title = $"☠️  {title}";
            subtitle = "The creeper caught you.";
            footer = "R  Retry   |   Esc  Quit";
        }
        else if (level == FinalLevel)
        {
            accent = ConsoleColor.Yellow;
            title = "VICTORY!";
            titleWidth = title.Length + (ascii ? 0 : 8);
            if (!ascii)
                title = $"🔥  {title}  👑";
            subtitle = "You escaped all three levels!";
            footer = "R  Replay   |   1-3  Select level   |   Esc";
        }
        else
        {
            accent = ConsoleColor.Cyan;
            title = "LEVEL PASSED!";
            titleWidth = title.Length;
            subtitle = "Prepare for next challenge";
            footer = $"Next up: Level {level + 1}";
        }

        void WriteRow(string text, ConsoleColor color, int visibleWidth)
        {
            int padding = innerWidth - visibleWidth;
            Console.ForegroundColor = accent;
            Console.Write($"{margin}{border[3]}{new string(' ', padding / 2)}");
            Console.ForegroundColor = color;
            Console.Write(text);
            Console.ForegroundColor = accent;
            Console.WriteLine($"{new string(' ', padding - padding / 2)}{border[3]}");
        }

        ConsoleColor previous = Console.ForegroundColor;
        try
        {
            Console.Clear();
            Console.SetCursorPosition(0, top);
            string rule = new(border[1], innerWidth);
            Console.ForegroundColor = accent;
            Console.WriteLine($"{margin}{border[0]}{rule}{border[2]}");
            WriteRow("", accent, 0);

            WriteRow(title, accent, titleWidth);
            WriteRow(subtitle, ConsoleColor.White, subtitle.Length);
            WriteRow("", accent, 0);
            WriteRow(footer, ConsoleColor.Gray, footer.Length);
            Console.WriteLine($"{margin}{border[4]}{rule}{border[5]}");
        }
        finally
        {
            Console.ForegroundColor = previous;
        }
    }

    [SupportedOSPlatform("windows")]
    private static class WindowsConsole
    {
        private const string OptionPrefix = "--mine-escape-terminal=";
        private const string ProfileId = "{a7057adb-23d2-44a2-8ef8-e3b733796755}";
        private const string FontFace = "Consolas";

        public static bool ContinueInThisWindow(string[] args, bool ascii, int columns, int rows)
        {
            string? childOption = Array.Find(args, arg => arg.StartsWith(OptionPrefix, StringComparison.Ordinal));
            if (childOption is not null)
            {
                if (!Guid.TryParseExact(childOption[OptionPrefix.Length..], "N", out var session))
                    return false;

                for (int attempt = 0; attempt < 10; attempt++)
                {
                    if (Console.WindowWidth >= columns && Console.WindowHeight >= rows)
                        return Signal(session, "ready");
                    Thread.Sleep(75);
                }
                Signal(session, "small");
                return false;
            }

            if (System.Diagnostics.Debugger.IsAttached)
            {
                Fit(columns, rows);
                return true;
            }

            IntPtr console = GetConsoleWindow();
            if (console != IntPtr.Zero && IsWindowVisible(console))
            {
                Fit(columns, rows);
                return true;
            }

            return !TryOpenTerminal(ascii, columns, rows);
        }

        private static string EventName(Guid session, string state) =>
            $@"Local\MineEscape-Terminal-{session:N}-{state}";

        private static bool Signal(Guid session, string state)
        {
            if (!EventWaitHandle.TryOpenExisting(EventName(session, state), out var signal))
                return false;
            using (signal)
                return signal.Set();
        }

        private static bool TryOpenTerminal(bool ascii, int columns, int rows)
        {
            string? program = Environment.ProcessPath;
            if (program is null)
                return false;

            try
            {
                var size = MeasureTerminal(columns, rows);
                if (size is not { } fit)
                    return false;

                var state = Guid.NewGuid();
                using var ready = new EventWaitHandle(false, EventResetMode.ManualReset, EventName(state, "ready"));
                using var tooSmall = new EventWaitHandle(false, EventResetMode.ManualReset, EventName(state, "small"));

                WriteTerminalProfile(fit.FontSize);
                var launch = new System.Diagnostics.ProcessStartInfo("wt.exe") { UseShellExecute = false };
                foreach (string arg in new[]
                {
                    "--window", "new", "--pos", $"{fit.Left},{fit.Top}",
                    "--size", $"{fit.Columns},{fit.Rows}", "new-tab", "--profile", ProfileId,
                    "--title", "Mine Escape", program
                })
                    launch.ArgumentList.Add(arg);

                // Running the DLL directly uses dotnet as the executable.
                if (string.Equals(Path.GetFileNameWithoutExtension(program), "dotnet", StringComparison.OrdinalIgnoreCase))
                {
                    string? entryAssembly = System.Reflection.Assembly.GetEntryAssembly()?.Location;
                    if (string.IsNullOrEmpty(entryAssembly))
                        return false;
                    launch.ArgumentList.Add(entryAssembly);
                }
                if (ascii)
                    launch.ArgumentList.Add("--ascii");
                launch.ArgumentList.Add(OptionPrefix + state.ToString("N"));

                using var terminal = System.Diagnostics.Process.Start(launch);
                return terminal is not null &&
                    WaitHandle.WaitAny(new WaitHandle[] { ready, tooSmall }, TimeSpan.FromSeconds(6)) == 0;
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException
                or System.ComponentModel.Win32Exception or InvalidOperationException or EntryPointNotFoundException)
            {
                // A disabled alias or managed workstation can prevent the extra window.
                return false;
            }
        }

        private static void WriteTerminalProfile(int fontSize)
        {
            string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string directory = Path.Combine(local, "Microsoft", "Windows Terminal", "Fragments", "MineEscape");
            Directory.CreateDirectory(directory);
            string path = Path.Combine(directory, "profile.json");
            string json = System.Text.Json.JsonSerializer.Serialize(new
            {
                profiles = new[] { new { guid = ProfileId, name = "Mine Escape", font = new { face = FontFace, size = fontSize } } }
            });

            if (File.Exists(path) && File.ReadAllText(path) == json)
                return;
            string temporary = Path.Combine(directory, Guid.NewGuid().ToString("N") + ".tmp");
            try
            {
                File.WriteAllText(temporary, json);
                File.Move(temporary, path, overwrite: true);
            }
            finally
            {
                File.Delete(temporary);
            }

            // Terminal watches settings.json, even when it is already open.
            // Refresh its timestamp only: its contents and existing profiles are untouched.
            bool reload = false;
            foreach (string settings in new[]
            {
                Path.Combine(local, "Packages", "Microsoft.WindowsTerminal_8wekyb3d8bbwe", "LocalState", "settings.json"),
                Path.Combine(local, "Packages", "Microsoft.WindowsTerminalPreview_8wekyb3d8bbwe", "LocalState", "settings.json"),
                Path.Combine(local, "Microsoft", "Windows Terminal", "settings.json")
            })
            {
                if (!File.Exists(settings))
                    continue;
                try
                {
                    File.SetLastWriteTimeUtc(settings, DateTime.UtcNow);
                    reload = true;
                }
                catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
                {
                    // A fresh Terminal instance can still load the fragment.
                }
            }
            if (reload)
                Thread.Sleep(450);
        }

        private static (int Left, int Top, int Columns, int Rows, int FontSize)? MeasureTerminal(int columns, int rows)
        {
            IntPtr oldContext = SetThreadDpiAwarenessContext(new IntPtr(-4)); // Per-monitor V2
            try
            {
                IntPtr foreground = GetForegroundWindow();
                IntPtr monitor = MonitorFromWindow(foreground, 2);
                var info = new MonitorInfo { Size = Marshal.SizeOf<MonitorInfo>() };
                if (!GetMonitorInfo(monitor, ref info))
                    return null;

                uint dpi = 96;
                if (GetDpiForMonitor(monitor, 0, out uint effectiveDpi, out _) == 0 && effectiveDpi > 0)
                    dpi = effectiveDpi;
                return FitProfile(info.Work, dpi, columns, rows);
            }
            finally
            {
                if (oldContext != IntPtr.Zero)
                    SetThreadDpiAwarenessContext(oldContext);
            }
        }

        private static (int Left, int Top, int Columns, int Rows, int FontSize)? FitProfile(
            Rect work, uint dpi, int columns, int rows)
        {
            int Scale(int pixels) => (int)Math.Ceiling(pixels * dpi / 96.0);
            // Reserve room for tabs, window chrome, scrollbar, and profile padding.
            int width = work.Width - Scale(44);
            int height = work.Height - Scale(100);
            IntPtr dc = CreateCompatibleDC(IntPtr.Zero);
            if (dc == IntPtr.Zero)
                return null;
            try
            {
                int upperBound = (int)Math.Min(120, height * 72.0 / (dpi * rows));
                for (int points = upperBound; points >= 8; points--)
                {
                    int pixels = (int)Math.Round(points * dpi / 72.0);
                    IntPtr font = CreateFont(-pixels, 0, 0, 0, 400, 0, 0, 0, 1, 0, 0, 0, 0, FontFace);
                    if (font == IntPtr.Zero)
                        continue;
                    IntPtr previous = SelectObject(dc, font);
                    try
                    {
                        if (previous == IntPtr.Zero || previous == new IntPtr(-1) ||
                            !GetTextExtentPoint32(dc, "M", 1, out var cell) || cell.X <= 0 || cell.Y <= 0)
                            continue;

                        int availableColumns = width / cell.X;
                        int availableRows = height / (cell.Y + 1);
                        if (availableColumns >= columns && availableRows >= rows)
                            return (work.Left + Scale(4), work.Top + Scale(4),
                                availableColumns, availableRows, points);
                    }
                    finally
                    {
                        if (previous != IntPtr.Zero && previous != new IntPtr(-1))
                            SelectObject(dc, previous);
                        DeleteObject(font);
                    }
                }
                return null;
            }
            finally
            {
                DeleteDC(dc);
            }
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct TextSize { public int X, Y; }

        [DllImport("user32.dll")]
        private static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll")]
        private static extern IntPtr SetThreadDpiAwarenessContext(IntPtr context);

        [DllImport("shcore.dll")]
        private static extern int GetDpiForMonitor(IntPtr monitor, int type, out uint x, out uint y);

        [DllImport("gdi32.dll")]
        private static extern IntPtr CreateCompatibleDC(IntPtr dc);

        [DllImport("gdi32.dll", EntryPoint = "CreateFontW", CharSet = CharSet.Unicode)]
        private static extern IntPtr CreateFont(int height, int width, int escapement, int orientation,
            int weight, uint italic, uint underline, uint strikeOut, uint charset, uint outputPrecision,
            uint clipPrecision, uint quality, uint pitchAndFamily, string face);

        [DllImport("gdi32.dll")]
        private static extern IntPtr SelectObject(IntPtr dc, IntPtr obj);

        [DllImport("gdi32.dll", EntryPoint = "GetTextExtentPoint32W", CharSet = CharSet.Unicode)]
        private static extern bool GetTextExtentPoint32(IntPtr dc, string text, int length, out TextSize size);

        [DllImport("gdi32.dll")]
        private static extern bool DeleteObject(IntPtr obj);

        [DllImport("gdi32.dll")]
        private static extern bool DeleteDC(IntPtr dc);

        public static void Fit(int columns, int rows)
        {
            IntPtr window = GetConsoleWindow();
            if (window == IntPtr.Zero || !IsWindowVisible(window) || IsZoomed(window))
                return;

            IntPtr output = GetStdHandle(-11); // STD_OUTPUT_HANDLE
            var info = new MonitorInfo { Size = Marshal.SizeOf<MonitorInfo>() };
            var original = new ConsoleFont { Size = Marshal.SizeOf<ConsoleFont>() };
            if (!GetMonitorInfo(MonitorFromWindow(window, 2), ref info) ||
                !GetWindowRect(window, out Rect outer) ||
                !GetClientRect(window, out Rect client) ||
                !GetCurrentConsoleFontEx(output, false, ref original))
                return;

            Rect work = info.Work;
            int frameWidth = outer.Width - client.Width;
            int frameHeight = outer.Height - client.Height;

            // Test requested sizes against the actual cell dimensions selected by the host.
            // A small margin leaves room for window borders and a possible scrollbar.
            for (int height = Math.Max(36, (int)original.CellHeight); height >= 8; height--)
            {
                var font = original;
                font.CellWidth = 0;
                font.CellHeight = (short)height;
                if (!SetCurrentConsoleFontEx(output, false, ref font) ||
                    !GetCurrentConsoleFontEx(output, false, ref font) ||
                    font.CellWidth <= 0 || font.CellHeight <= 0)
                    continue;

                int availableWidth = (work.Width - frameWidth - 8) / font.CellWidth;
                int availableHeight = (work.Height - frameHeight - 4) / font.CellHeight;
                Coord limit = GetLargestConsoleWindowSize(output);
                if (Math.Min(availableWidth, limit.X) < columns ||
                    Math.Min(availableHeight, limit.Y) < rows)
                    continue;

                // Move and resize the normal window within the monitor's work area.
                if (MoveWindow(window, work.Left, work.Top, work.Width, work.Height, true) &&
                    Console.WindowWidth >= columns && Console.WindowHeight >= rows)
                    return;
            }

            SetCurrentConsoleFontEx(output, false, ref original);
            MoveWindow(window, outer.Left, outer.Top, outer.Width, outer.Height, true);
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct Coord { public short X, Y; }

        [StructLayout(LayoutKind.Sequential)]
        private struct Rect
        {
            public int Left, Top, Right, Bottom;
            public readonly int Width => Right - Left;
            public readonly int Height => Bottom - Top;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct MonitorInfo
        {
            public int Size;
            public Rect Monitor, Work;
            public uint Flags;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        private struct ConsoleFont
        {
            public int Size;
            public uint Index;
            public short CellWidth, CellHeight;
            public int Family, Weight;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
            public string FaceName;
        }

        [DllImport("kernel32.dll")]
        private static extern IntPtr GetConsoleWindow();

        [DllImport("kernel32.dll")]
        private static extern IntPtr GetStdHandle(int handle);

        [DllImport("kernel32.dll")]
        private static extern bool GetCurrentConsoleFontEx(IntPtr output, bool maximum, ref ConsoleFont font);

        [DllImport("kernel32.dll")]
        private static extern bool SetCurrentConsoleFontEx(IntPtr output, bool maximum, ref ConsoleFont font);

        [DllImport("kernel32.dll")]
        private static extern Coord GetLargestConsoleWindowSize(IntPtr output);

        [DllImport("user32.dll")]
        private static extern bool IsWindowVisible(IntPtr window);

        [DllImport("user32.dll")]
        private static extern bool IsZoomed(IntPtr window);

        [DllImport("user32.dll")]
        private static extern IntPtr MonitorFromWindow(IntPtr window, uint flags);

        [DllImport("user32.dll", EntryPoint = "GetMonitorInfoW")]
        private static extern bool GetMonitorInfo(IntPtr monitor, ref MonitorInfo info);

        [DllImport("user32.dll")]
        private static extern bool GetWindowRect(IntPtr window, out Rect rect);

        [DllImport("user32.dll")]
        private static extern bool GetClientRect(IntPtr window, out Rect rect);

        [DllImport("user32.dll")]
        private static extern bool MoveWindow(IntPtr window, int x, int y, int width, int height, bool repaint);
    }

}
